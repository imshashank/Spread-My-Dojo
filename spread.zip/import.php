<?php
if ( move_uploaded_file ($_FILES['uploadFile'] ['tmp_name'], 
       "./uploads/{$_FILES['uploadFile'] ['name']}")  )
      {  print '<p> The file has been successfully uploaded </p>';
       }
else
      { 
        switch ($_FILES['uploadFile'] ['error'])
         {  case 1:
                   print '<p> The file is bigger than this PHP installation allows</p>';
                   break;
            case 2:
                   print '<p> The file is bigger than this form allows</p>';
                   break;
            case 3:
                   print '<p> Only part of the file was uploaded</p>';
                   break;
            case 4:
                   print '<p> No file was uploaded</p>';
                   break;
         }
       }
?>
<?php 

    if( ! $xml = simplexml_load_file('address.xml') ) 
    { 
        echo 'unable to load XML file'; 
    } 
    else 
    { 
        foreach( $xml as $user ) 
        { 
            echo 'Firstname: '.$user->firstname.'<br />'; 
            echo 'Surname: '.$user->surname.'<br />'; 
            echo 'Email: '.$user->email.'<br />'; 
            echo 'Country: '.$user->country.'<br />'; 
        } 
    } 

?> 

<form action= <?php echo $_SERVER['PHP_SELF'] ?> method="post">
Type (or select) Filename: <input type="file" name="uploadFile">
<input type="hidden" name="MAX_FILE_SIZE" value="25000" />
<input type="submit" value="Upload File">
</form>



