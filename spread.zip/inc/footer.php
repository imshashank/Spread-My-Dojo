    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/osu_hackathon_2014/js/bootstrap.min.js"></script>
	<!--<script src="/osu_hackathon_2014/js/jasny-bootstrap.min.js.js"></script>	-->
  </body>
</html>